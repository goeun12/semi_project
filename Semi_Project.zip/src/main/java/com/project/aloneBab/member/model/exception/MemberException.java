package com.project.aloneBab.member.model.exception;

public class MemberException extends RuntimeException{
	public MemberException() {}
	public MemberException(String msg) {super(msg);}
}
