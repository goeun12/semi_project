package com.project.aloneBab.member.model.service;

import com.project.aloneBab.member.model.vo.Member;

public interface MemberService {

	Member login(Member m);

	Member findId(Member m);

	Member findPw(Member m);

	void updatePwd(Member member);

	int checkId(String id);

	int joinMember(Member m);

}
