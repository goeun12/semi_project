package com.project.aloneBab.board.model.exception;

public class BoardException {

}
