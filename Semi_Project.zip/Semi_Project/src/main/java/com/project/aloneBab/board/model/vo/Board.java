package com.project.aloneBab.board.model.vo;

public class Board {

}
