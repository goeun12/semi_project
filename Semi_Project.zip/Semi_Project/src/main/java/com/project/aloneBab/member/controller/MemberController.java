package com.project.aloneBab.member.controller;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.google.gson.Gson;
import com.project.aloneBab.member.model.exception.MemberException;
import com.project.aloneBab.member.model.service.MemberService;
import com.project.aloneBab.member.model.vo.Member;

@Controller
@SessionAttributes("loginUser")
public class MemberController {
	
	@Autowired
	private BCryptPasswordEncoder bcrypt;
	
	@Autowired
	private MemberService mService;
	
	// 로그인 화면으로 이동
	@RequestMapping("loginView.user")
	public String loginView(Model model) {
		
		return "login_user";
	}
	
	// 로그인 과정
	@RequestMapping("login.user")
	public String login(@ModelAttribute Member m,
						@RequestParam("change") String change,
						Model model,
						HttpSession session) {
		Member loginUser = mService.login(m);
		
		if(bcrypt.matches(m.getPwd(), loginUser.getPwd())) {
			session.setAttribute("loginUser", loginUser);
			
			if(change.equals("Y")) {
				return "redirect:edit.user";	// 회원 정보 수정 페이지로 가기
			} else {
				return "redirect:recipe.re";	// 레시피 리스트로 가기
			}
		} else {
			throw new MemberException("로그인에 실패하였습니다.");
		}
	}
	
	// 로그아웃
	@RequestMapping("logout.user")
	public String logout(SessionStatus session) {
		session.setComplete();
		
		return "redirect:loginView.user";
	}
	
	// 아이디/비밀번호 찾기 화면으로 이동
	@RequestMapping("findInfo.user")
	public String findInfoView() {
		
		return "id_find";
	}
	
	// 아이디 찾기 화면으로 이동
	@RequestMapping("findIdView.user")
	public String findIdView() {
		
		return "id_find";
	}	
	
	// 아이디 찾기 과정		-> Ajax 활용?
	@RequestMapping("findId.user")
	@ResponseBody
	public void findId(@ModelAttribute Member m,
					   HttpServletResponse response) {
		Member user = mService.findId(m);
		
		Gson gson = new Gson();
		response.setContentType("application/json; charset=UTF-8");
		try {
			gson.toJson(user, response.getWriter());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 비밀번호 찾기 화면으로 이동
	@RequestMapping("findPwView.user")
	public String findPwView() {
		
		return "pw_find";
	}
	
	// 비밀번호 찾기 과정		-> Ajax 활용?
	@RequestMapping("findPw.user")
	@ResponseBody
	public void findPw(@ModelAttribute Member m,
					   HttpServletResponse response) {
		Member user = mService.findPw(m);
		
		if(user != null) {
			int num = (int)(Math.random() * 1000000);
			String rowPwd = String.valueOf(num);
			
			while(rowPwd.length() != 6) {
				rowPwd += "0";
			}
			
			String pwd = bcrypt.encode(rowPwd);
			Member member = new Member();
			member.setId(user.getId());
			member.setPwd(pwd);
			
			mService.updatePwd(member);
			
			user.setPwd(rowPwd);
		}
		
		Gson gson = new Gson();
		response.setContentType("application/json; charset=UTF-8");
		try {
			gson.toJson(user, response.getWriter());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	// 회원이 작성한 게시글 목록 화면으로 이동
	@RequestMapping("write.user")
	public String writePageView() {
		
		return "myWritePage";
	}
	
	// 회원이 작성한 게시글 클릭해서 상세 페이지 이동	-> BoardController에서 작성
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	// 회원가입 화면으로 이동
	@RequestMapping("joinView.user")
	public String joinView() {
		
		return "join_account";
	}
	
	// 회원정보 수정 화면으로 이동
	@RequestMapping("edit.user")
	public String editView() {
		
		return "modify_account";
	}
	
}
