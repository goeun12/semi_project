package com.project.aloneBab.board.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BoardController {
	
	// 레시피 목록 페이지 이동
	@RequestMapping("recipe.re")
	public String recipeListView() {
		
		return "recipeList";
	}
	
	// 레시피 작성 페이지 이동
	@RequestMapping("write.re")
	public String recipeWriteView() {
		
		return "recipeWrite";
	}
	
	// 꿀팁 목록 페이지 이동
	@RequestMapping("tip.tip")
	public String tipListView() {
		
		return "tipList";
	}
	
	// 꿀팁 작성 페이지 이동
	@RequestMapping("write.tip")
	public String tipWriteView() {
		
		return "tipWrite";
	}
	
	
	// 랜덤메뉴 페이지 이동
	@RequestMapping("random.re")
	public String randomView() {
		
		return "randomMenu";
	}
	
	// 공지사항 목록 페이지 이동
	@RequestMapping("notice.no")
	public String noticeListView() {
		
		return "noticeList";
	}
	
	// 공지사항 작성 페이지 이동
	@RequestMapping("write.no")
	public String noticeWriteView() {
		
		return "noticeWrite";
	}
	
	// 공지사항 수정
	@RequestMapping("edit.no")
	public String noticeEdit() {
		
		return null;
	}
	
	
	
}
