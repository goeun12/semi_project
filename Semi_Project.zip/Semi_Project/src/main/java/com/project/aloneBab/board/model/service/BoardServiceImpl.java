package com.project.aloneBab.board.model.service;

public class BoardServiceImpl {

}
