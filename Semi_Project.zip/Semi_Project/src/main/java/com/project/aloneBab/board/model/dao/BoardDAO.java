package com.project.aloneBab.board.model.dao;

public class BoardDAO {

}
